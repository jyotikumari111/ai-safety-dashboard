import { useState } from "react";
import IncidentList from "./components/IncidentList";
import FilterSortControls from "./components/FilterSortControls";
import IncidentForm from "./components/IncidentForm";
import './index.css';

export type Incident = {
  id: number;
  title: string;
  description: string;
  severity: "Low" | "Medium" | "High";
  reported_at: string;
};

const initialIncidents: Incident[] = [
  {
    id: 1,
    title: "Biased Recommendation Algorithm",
    description: "Algorithm consistently favored certain demographics...",
    severity: "Medium",
    reported_at: "2025-03-15T10:00:00Z",
  },
  {
    id: 2,
    title: "LLM Hallucination in Critical Info",
    description: "LLM provided incorrect safety procedure information...",
    severity: "High",
    reported_at: "2025-04-01T14:30:00Z",
  },
  {
    id: 3,
    title: "Minor Data Leak via Chatbot",
    description: "Chatbot inadvertently exposed non-sensitive user metadata...",
    severity: "Low",
    reported_at: "2025-03-20T09:15:00Z",
  },
];

function App() {
  const [incidents, setIncidents] = useState<Incident[]>(initialIncidents);
  const [filter, setFilter] = useState<"All" | "Low" | "Medium" | "High">("All");
  const [sortOrder, setSortOrder] = useState<"Newest" | "Oldest">("Newest");

  const addIncident = (newIncident: Incident) => {
    setIncidents((prev) => [newIncident, ...prev]);
  };

  return (
    <div className="min-h-screen bg-gray-100 p-6 space-y-8">
      <h1 className="text-3xl font-bold text-center">AI Safety Incident Dashboard</h1>

      <FilterSortControls
        filter={filter}
        setFilter={setFilter}
        sortOrder={sortOrder}
        setSortOrder={setSortOrder}
      />

      <IncidentForm onAddIncident={addIncident} />

      <IncidentList
        incidents={incidents}
        filter={filter}
        sortOrder={sortOrder}
      />
    </div>
  );
}

export default App;



// import { useState } from "react";
// import { Incident } from "../App";

// type Props = {
//   incidents: Incident[];
//   filter: "All" | "Low" | "Medium" | "High";
//   sortOrder: "Newest" | "Oldest";
// };

// const IncidentList = ({ incidents, filter, sortOrder }: Props) => {
//   const [expandedId, setExpandedId] = useState<number | null>(null);

//   const filteredIncidents = incidents.filter((incident) => {
//     if (filter === "All") return true;
//     return incident.severity === filter;
//   });

//   const sortedIncidents = filteredIncidents.sort((a, b) => {
//     const dateA = new Date(a.reported_at).getTime();
//     const dateB = new Date(b.reported_at).getTime();
//     return sortOrder === "Newest" ? dateB - dateA : dateA - dateB;
//   });

//   const toggleExpand = (id: number) => {
//     setExpandedId((prevId) => (prevId === id ? null : id));
//   };

//   return (
//     <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
//       {sortedIncidents.map((incident) => (
//         <div
//           key={incident.id}
//           className="bg-white p-6 rounded-2xl shadow-md hover:shadow-lg transition-shadow duration-300 cursor-pointer"
//           onClick={() => toggleExpand(incident.id)}
//         >
//           <div className="flex justify-between items-center mb-2">
//             <h2 className="text-xl font-semibold">{incident.title}</h2>
//             <span
//               className={`px-3 py-1 text-sm rounded-full ${
//                 incident.severity === "High"
//                   ? "bg-red-100 text-red-700"
//                   : incident.severity === "Medium"
//                   ? "bg-yellow-100 text-yellow-700"
//                   : "bg-green-100 text-green-700"
//               }`}
//             >
//               {incident.severity}
//             </span>
//           </div>

//           <p className="text-gray-500 text-sm mb-4">
//             Reported on: {new Date(incident.reported_at).toLocaleDateString()}
//           </p>

//           {expandedId === incident.id && (
//             <p className="text-gray-700 mt-4 animate-fadeIn">{incident.description}</p>
//           )}

//           <button className="mt-4 text-blue-500 hover:underline">
//             {expandedId === incident.id ? "Hide Details" : "View Details"}
//           </button>
//         </div>
//       ))}
//     </div>
//   );
// };

// export default IncidentList;
