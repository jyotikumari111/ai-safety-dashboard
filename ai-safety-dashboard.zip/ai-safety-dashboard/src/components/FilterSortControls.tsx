// interface Props {
//     filter: string;
//     setFilter: (value: string) => void;
//     sortOrder: string;
//     setSortOrder: (value: string) => void;
//   }
  
//   const FilterSortControls = ({ filter, setFilter, sortOrder, setSortOrder }: Props) => {
//     return (
//       <div className="flex flex-wrap gap-4 mb-6">
//         <select value={filter} onChange={(e) => setFilter(e.target.value)} className="p-2 border rounded">
//           <option value="All">All Severities</option>
//           <option value="Low">Low</option>
//           <option value="Medium">Medium</option>
//           <option value="High">High</option>
//         </select>
  
//         <select value={sortOrder} onChange={(e) => setSortOrder(e.target.value)} className="p-2 border rounded">
//           <option value="newest">Newest First</option>
//           <option value="oldest">Oldest First</option>
//         </select>
//       </div>
//     );
//   };
  
//   export default FilterSortControls;
  
import { Dispatch, SetStateAction } from "react";

type Props = {
  filter: "All" | "Low" | "Medium" | "High";
  setFilter: Dispatch<SetStateAction<"All" | "Low" | "Medium" | "High">>;
  sortOrder: "Newest" | "Oldest";
  setSortOrder: Dispatch<SetStateAction<"Newest" | "Oldest">>;
};

const FilterSortControls = ({ filter, setFilter, sortOrder, setSortOrder }: Props) => {
  return (
    <center>
    <div className="flex flex-wrap gap-4 items-center justify-between bg-white p-4 rounded-lg shadow">
      <div className="flex gap-2">
        <label className="font-medium">Filter Severity:</label>
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value as "All" | "Low" | "Medium" | "High")}
          className="border rounded p-1"
        >
          <option value="All">All</option>
          <option value="Low">Low</option>
          <option value="Medium">Medium</option>
          <option value="High">High</option>
        </select>
      </div>

      <div className="flex gap-2">
        <label className="font-medium">Sort Date:</label>
        <select
          value={sortOrder}
          onChange={(e) => setSortOrder(e.target.value as "Newest" | "Oldest")}
          className="border rounded p-1"
        >
          <option value="Newest">Newest First</option>
          <option value="Oldest">Oldest First</option>
        </select>
      </div>
    </div></center>
  );
};

export default FilterSortControls;
