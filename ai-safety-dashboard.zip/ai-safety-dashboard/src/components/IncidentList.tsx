// // // // import { Incident } from "../data/incidents";
// // // // import { useState } from "react";

// // // // interface Props {
// // // //   incidents: Incident[];
// // // // }

// // // // const IncidentList = ({ incidents }: Props) => {
// // // //   const [expandedId, setExpandedId] = useState<number | null>(null);

// // // //   const toggleDescription = (id: number) => {
// // // //     setExpandedId(prev => (prev === id ? null : id));
// // // //   };

// // // //   return (
// // // //     <div className="grid gap-4">
// // // //       {incidents.map((incident) => (
// // // //         <div key={incident.id} className="border rounded p-4 shadow hover:shadow-lg">
// // // //           <div className="flex justify-between items-center">
// // // //             <div>
// // // //               <h2 className="font-bold">{incident.title}</h2>
// // // //               <p>Severity: {incident.severity}</p>
// // // //               <p>Reported: {new Date(incident.reported_at).toLocaleDateString()}</p>
// // // //             </div>
// // // //             <button
// // // //               onClick={() => toggleDescription(incident.id)}
// // // //               className="bg-blue-500 text-white px-3 py-1 rounded hover:bg-blue-600"
// // // //             >
// // // //               {expandedId === incident.id ? "Hide Details" : "View Details"}
// // // //             </button>
// // // //           </div>
// // // //           {expandedId === incident.id && (
// // // //             <p className="mt-2 text-gray-700">{incident.description}</p>
// // // //           )}
// // // //         </div>
// // // //       ))}
// // // //     </div>
// // // //   );
// // // // };

// // // // export default IncidentList;

// // // import { useState } from "react";
// // // import { Incident } from "../App";

// // // type Props = {
// // //   incidents: Incident[];
// // //   filter: "All" | "Low" | "Medium" | "High";
// // //   sortOrder: "Newest" | "Oldest";
// // // };

// // // const IncidentList = ({ incidents, filter, sortOrder }: Props) => {
// // //   const [expandedIds, setExpandedIds] = useState<number[]>([]);

// // //   const toggleExpand = (id: number) => {
// // //     setExpandedIds((prev) =>
// // //       prev.includes(id) ? prev.filter((eid) => eid !== id) : [...prev, id]
// // //     );
// // //   };

// // //   const filteredIncidents = incidents.filter((incident) =>
// // //     filter === "All" ? true : incident.severity === filter
// // //   );

// // //   const sortedIncidents = filteredIncidents.sort((a, b) => {
// // //     if (sortOrder === "Newest") {
// // //       return new Date(b.reported_at).getTime() - new Date(a.reported_at).getTime();
// // //     } else {
// // //       return new Date(a.reported_at).getTime() - new Date(b.reported_at).getTime();
// // //     }
// // //   });

// // //   return (
// // //     <div className="space-y-4">
// // //       {sortedIncidents.map((incident) => (
// // //         <div key={incident.id} className="bg-white p-4 rounded-lg shadow hover:shadow-md transition">
// // //           <div className="flex justify-between items-center">
// // //             <div>
// // //               <h2 className="text-lg font-semibold">{incident.title}</h2>
// // //               <p className="text-sm text-gray-600">
// // //                 Severity: <span className="font-medium">{incident.severity}</span> |{" "}
// // //                 {new Date(incident.reported_at).toLocaleDateString()}
// // //               </p>
// // //             </div>
// // //             <button
// // //               onClick={() => toggleExpand(incident.id)}
// // //               className="text-blue-500 hover:underline text-sm"
// // //             >
// // //               {expandedIds.includes(incident.id) ? "Hide Details" : "View Details"}
// // //             </button>
// // //           </div>

// // //           {expandedIds.includes(incident.id) && (
// // //             <p className="mt-2 text-gray-700">{incident.description}</p>
// // //           )}
// // //         </div>
// // //       ))}
// // //     </div>
// // //   );
// // // };

// // // export default IncidentList;

// // import { useState } from "react";
// // import { Incident } from "../App";

// // type Props = {
// //   incidents: Incident[];
// //   filter: "All" | "Low" | "Medium" | "High";
// //   sortOrder: "Newest" | "Oldest";
// // };

// // const IncidentList = ({ incidents, filter, sortOrder }: Props) => {
// //   const [expandedId, setExpandedId] = useState<number | null>(null);

// //   const filteredIncidents = incidents.filter((incident) => {
// //     if (filter === "All") return true;
// //     return incident.severity === filter;
// //   });

// //   const sortedIncidents = filteredIncidents.sort((a, b) => {
// //     const dateA = new Date(a.reported_at).getTime();
// //     const dateB = new Date(b.reported_at).getTime();
// //     return sortOrder === "Newest" ? dateB - dateA : dateA - dateB;
// //   });

// //   const toggleExpand = (id: number) => {
// //     setExpandedId((prevId) => (prevId === id ? null : id));
// //   };

// //   return (
// //     <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
// //       {sortedIncidents.map((incident) => (
// //         <div
// //           key={incident.id}
// //           className="bg-white p-6 rounded-2xl shadow-md hover:shadow-lg transition-shadow duration-300 cursor-pointer"
// //           onClick={() => toggleExpand(incident.id)}
// //         >
// //           <div className="flex justify-between items-center mb-2">
// //             <h2 className="text-xl font-semibold">{incident.title}</h2>
// //             <span
// //               className={`px-3 py-1 text-sm rounded-full ${
// //                 incident.severity === "High"
// //                   ? "bg-red-100 text-red-700"
// //                   : incident.severity === "Medium"
// //                   ? "bg-yellow-100 text-yellow-700"
// //                   : "bg-green-100 text-green-700"
// //               }`}
// //             >
// //               {incident.severity}
// //             </span>
// //           </div>

// //           <p className="text-gray-500 text-sm mb-4">
// //             Reported on: {new Date(incident.reported_at).toLocaleDateString()}
// //           </p>

// //           {expandedId === incident.id && (
// //             <p className="text-gray-700 mt-4 animate-fadeIn">{incident.description}</p>
// //           )}

// //           <button className="mt-4 text-blue-500 hover:underline">
// //             {expandedId === incident.id ? "Hide Details" : "View Details"}
// //           </button>
// //         </div>
// //       ))}
// //     </div>
// //   );
// // };

// // export default IncidentList;

// import { useState } from "react";

// type Props = {
//   onSubmit: (incident: { title: string; description: string; severity: string }) => void;
// };

// const IncidentForm = ({ onSubmit }: Props) => {
//   const [title, setTitle] = useState("");
//   const [description, setDescription] = useState("");
//   const [severity, setSeverity] = useState("Low");

//   const handleSubmit = (e: React.FormEvent) => {
//     e.preventDefault();

//     // Basic validation: Ensure all fields are filled out
//     if (!title || !description || !severity) {
//       alert("Please fill out all fields!");
//       return;
//     }

//     onSubmit({
//       title,
//       description,
//       severity,
//     });

//     // Reset form after submit
//     setTitle("");
//     setDescription("");
//     setSeverity("Low");
//   };

//   return (
//     <form
//       onSubmit={handleSubmit}
//       className="bg-white p-6 rounded-lg shadow-lg max-w-lg mx-auto mt-8"
//     >
//       <h2 className="text-2xl font-semibold mb-4">Report New Incident</h2>

//       <div className="mb-4">
//         <label htmlFor="title" className="block text-sm font-medium text-gray-700">
//           Title
//         </label>
//         <input
//           type="text"
//           id="title"
//           value={title}
//           onChange={(e) => setTitle(e.target.value)}
//           className="w-full p-3 border border-gray-300 rounded-md mt-2"
//           placeholder="Incident Title"
//         />
//       </div>

//       <div className="mb-4">
//         <label htmlFor="description" className="block text-sm font-medium text-gray-700">
//           Description
//         </label>
//         <textarea
//           id="description"
//           value={description}
//           onChange={(e) => setDescription(e.target.value)}
//           className="w-full p-3 border border-gray-300 rounded-md mt-2"
//           placeholder="Incident Description"
//           rows={4}
//         />
//       </div>

//       <div className="mb-6">
//         <label htmlFor="severity" className="block text-sm font-medium text-gray-700">
//           Severity
//         </label>
//         <select
//           id="severity"
//           value={severity}
//           onChange={(e) => setSeverity(e.target.value)}
//           className="w-full p-3 border border-gray-300 rounded-md mt-2"
//         >
//           <option value="Low">Low</option>
//           <option value="Medium">Medium</option>
//           <option value="High">High</option>
//         </select>
//       </div>

//       <button
//         type="submit"
//         className="w-full bg-blue-500 text-white p-3 rounded-md font-semibold hover:bg-blue-600 transition-all"
//       >
//         Submit Incident
//       </button>
//     </form>
//   );
// };

// export default IncidentForm;
import { useState } from "react";
import { Incident } from "../App";


type Props = {
  incidents: Incident[];
  filter: "All" | "Low" | "Medium" | "High";
  sortOrder: "Newest" | "Oldest";
};

const IncidentList = ({ incidents, filter, sortOrder }: Props) => {
  const [expandedId, setExpandedId] = useState<number | null>(null);

  const filteredIncidents = incidents.filter((incident) => {
    if (filter === "All") return true;
    return incident.severity === filter;
  });

  const sortedIncidents = filteredIncidents.sort((a, b) => {
    const dateA = new Date(a.reported_at).getTime();
    const dateB = new Date(b.reported_at).getTime();
    return sortOrder === "Newest" ? dateB - dateA : dateA - dateB;
  });

  const toggleExpand = (id: number) => {
    setExpandedId((prevId) => (prevId === id ? null : id));
  };

  return (
    <div className="formm">
      <div className="form-container">
    <div  className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {sortedIncidents.map((incident) => (
        <div
          key={incident.id}
          className="bg-white p-6 rounded-2xl shadow-md hover:shadow-lg transition-shadow duration-300 cursor-pointer"
          onClick={() => toggleExpand(incident.id)}
        >
          <div className="flex justify-between items-center mb-2">
            <h2 className="text-xl font-semibold">{incident.title}</h2>
            <span
              className={`px-3 py-1 text-sm rounded-full ${
                incident.severity === "High"
                  ? "bg-red-100 text-red-700"
                  : incident.severity === "Medium"
                  ? "bg-yellow-100 text-yellow-700"
                  : "bg-green-100 text-green-700"
              }`}
            >
              {incident.severity}
            </span>
          </div>

          <p className="text-gray-500 text-sm mb-4">
            Reported on: {new Date(incident.reported_at).toLocaleDateString()}
          </p>

          {expandedId === incident.id && (
            <p className="text-gray-700 mt-4 animate-fadeIn">{incident.description}</p>
          )}

          <button className="mt-4 text-blue-500 hover:underline">
            {expandedId === incident.id ? "Hide Details" : "View Details"}
          </button>
        </div>
      ))}
    </div>
    </div></div>
  );
};

export default IncidentList;
