import { useState } from "react";
import { Incident } from "../App";

type Props = {
  onAddIncident: (newIncident: Incident) => void;
};

const IncidentForm = ({ onAddIncident }: Props) => {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [severity, setSeverity] = useState<"Low" | "Medium" | "High">("Low");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !description.trim()) {
      alert("Please fill in all fields.");
      return;
    }

    const newIncident: Incident = {
      id: Date.now(), // simple unique ID
      title,
      description,
      severity,
      reported_at: new Date().toISOString(),
    };

    onAddIncident(newIncident);

    // Clear the form
    setTitle("");
    setDescription("");
    setSeverity("Low");
  };

  return (
    <div className="formm">
      <div className="form-container">
    <form onSubmit={handleSubmit} className="bg-white p-4 rounded-lg shadow space-y-4">
        
      <h2 className="text-lg font-semibold mb-2"><center>Report New Incident</center></h2>
<hr></hr>
      <div>
        <label className="block font-medium mb-1">Title  :</label>
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className="border rounded w-full p-2"
          placeholder="Enter incident title"
        />
      </div>

      <div>
        <label className="block font-medium mb-1">Description:</label>
        <textarea
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className="border rounded w-full p-2"
          placeholder="Describe the incident"
        ></textarea>
      </div>

      <div>
        <label className="block font-medium mb-1">Severity  :</label>
        <select
          value={severity}
          onChange={(e) => setSeverity(e.target.value as "Low" | "Medium" | "High")}
          className="border rounded w-full p-2"
        >
          <option value="Low">Low</option>
          <option value="Medium">Medium</option>
          <option value="High">High</option>
        </select>
      </div>
<center>
      <button
        type="submit"
        className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition"
      >
        Submit
      </button></center>
    </form></div></div>
  );
};

export default IncidentForm;
